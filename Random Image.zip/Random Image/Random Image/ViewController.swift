//
//  ViewController.swift
//  Random Image
//
//  Created by Бекболат Бейсен on 21.10.2022.
//

import UIKit

class ViewController: UIViewController {
    let imageSet: [UIImage] = [#imageLiteral(resourceName: "Геральт"), #imageLiteral(resourceName: "Весемир"), #imageLiteral(resourceName: "Эскель"), #imageLiteral(resourceName: "Ламберт"), #imageLiteral(resourceName: "Койон 1"), #imageLiteral(resourceName: "Лютик"), #imageLiteral(resourceName: "Эмиель Регис"), #imageLiteral(resourceName: "Кагыр Маур Дыффин аэп Кеаллах"), #imageLiteral(resourceName: "Трисс Меригольд"), #imageLiteral(resourceName: "Цирилла"), #imageLiteral(resourceName: "Фалька"), #imageLiteral(resourceName: "Эмгыр вар Эмрейс"), #imageLiteral(resourceName: "Йеннифэр")]
    let textSet: [String] = ["Geralt", "Vesemir", "Eskel", "Lambert", "Koyon", "Jaskier", "Emiel Regis", "Cahir Mawr Dyffryn aep Ceallach", "Triss Merigold", "Ciri", "Falka", "Emhyr var Emreis", "Yennefer z Vengerbergu"]

    @IBOutlet weak var imgSet: UIImageView!
    @IBOutlet weak var textRandomSet: UILabel!
    @IBOutlet weak var myProgName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        textRandomSet.text = "Geralt"
        imgSet.image = #imageLiteral(resourceName: "Геральт")
        
        
    }


    @IBOutlet var backFont: UIView!
    @IBAction func rollsButton(_ sender: Any) {
        let random = Int.random(in: 0...10)
        textRandomSet.text = textSet[random]
        imgSet.image = imageSet[random]
        
        
    }
    
}

